"""
`example1` script for protograf

Written by: Derek Hohls
Created on: 29 February 2016
"""
from protograf import *

Create()
PageBreak()
Save()
