"""
`cards1` example for pyprototypr

Written by: Derek Hohls
Created on: 29 February 2016
"""
from pyprototypr import *

Create()
Deck())
Save()
