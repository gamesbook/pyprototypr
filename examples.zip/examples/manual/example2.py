"""
`example2` script for pyprototypr

Written by: Derek Hohls
Created on: 29 February 2016
"""
from pyprototypr import *

Create()
Text(text="Hello World")
PageBreak()
Save()
