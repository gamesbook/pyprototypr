"""
`counters1` example for pyprototypr

Written by: Derek Hohls
Created on: 22 September 2024
"""
from pyprototypr import *

Create()
CounterSheet()
Save()
