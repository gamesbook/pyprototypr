# -*- coding: utf-8 -*-
"""
Example protograf code for creating various "real world" things

Written by: Derek Hohls
Created on: 19 August 2024

Credits:
    tmwtgg.jpg: https://unsplash.com/photos/tropical-islands-rise-from-the-emerald-green-ocean-5xMpaSXnBwc

"""
from protograf import *

Create(filename="objects.pdf",
       margin=1,
       margin_top=0.25)

header = Common(x=0, y=1, font_size=24, align="left")
header_font = Common(font_size=16, align="left")
fidred = "#CC0033"

# ---- PAGE 1 ===>

Text(common=header, text="Miscellaneous Things #1")


Text(common=header_font, x=6, y=4,
     text="Coin: circle with steps-created radii & centre circle")
Circle(
   cx=3, cy=4, radius=2,
   fill="gold", stroke_width=2,
   radii=steps(0,360,15), # one every 15 degrees i.e. 24 total
   centre_shape=circle(
       radius=1.5,
       fill="gold", label="5", font_size=48)
)


Text(align="left", x=9, y=8, wrap=True, width=10, height=4, font_size=16,
     text='Warning Sign: rounded rectangles + a sequence of "E" (east) chevrons')
Rectangle(x=1, y=7.8, width=7.5, height=3, rounded=0.5,
          stroke="black", fill="black")
Rectangle(x=1.1, y=7.9, width=7.3, height=2.8, rounded=0.5,
          stroke_width=2, stroke="yellow", fill=None)
Sequence(
    rectangle(x=1.5, y=7.9, width=1, height=2.8,
              chevron='E', chevron_height=1,
              stroke="yellow", fill="yellow"),
    setting=(1, 3),
    interval_x=2)


Text(common=header_font, x=5, y=13,
     text="Leaded Window: rectangle with diagonal hatches")
Rectangle(
    x=2, y=12,
    height=3, width=2,
    hatches_count=7, hatches_stroke_width=0.1, hatches='d', hatches_stroke="black",
    stroke="saddlebrown", stroke_width=2, fill="lightcyan")


Text(common=header_font, x=5, y=17,
     text="Paned Window: rectangle with single orthogonal hatches")
Rectangle(
    x=2, y=16,
    height=3, width=2,
    hatches_count=1, hatches_stroke_width=1, hatches='o', hatches_stroke="sienna",
    stroke="sienna", stroke_width=3, fill="lightcyan")


Text(common=header_font, x=5, y=21,
     text="Start Player Token: circles + radii via steps")
Polygon(
    cx=3, cy=21, height=3,
    sides=8, fill="black",
    centre_shapes=[
        circle(
            fill="black", radius=1.25,
            radii=steps(0, 315, 45),
            radii_stroke="gold",
            radii_stroke_width=2),
        circle(
            stroke="black", fill="gold",
            radius=0.5, stroke_width=5)
        ]
)


Text(common=header_font, x=5, y=26,
     text="Doorway: stadium with dashed line; circle + radii")
Stadium(x=1.503, y=25.003, height=3.003, width=3.003,
        fill="white", edges="n",
        stroke="#CC0033", stroke_width=5, dashed=[0.3,0.05],)
Circle(cx=3, cy=25, radius=1.3,
       stroke="sienna", stroke_width=5, fill="skyblue",
       radii=[150,90,30], radii_stroke="sienna", radii_stroke_width=3)
Circle(cx=3, cy=25, radius=0.3,
       stroke="sienna", stroke_width=5, fill="sienna")
Rectangle(x=1.7, y=25.1, height=2.9, width=2.6,
          stroke="sienna", stroke_width=5, fill="skyblue")

PageBreak()

# ---- PAGE 2 ===>

Text(common=header,
     text="Miscellaneous Things #2")


Text(common=header_font, x=7, y=2.5, text="Sets of check boxes (loop + 3 x sequence)")
for s in steps(0, 6, 2.2):
    Sequence(
        [rectangle(fill_stroke="black", x=s+0.05, y=2.05, height=0.5, width=0.5),
         rectangle(stroke="black", x=s+0, y=2, height=0.5, width=0.5)],
        setting=(1, 3),
        interval_x=0.6)


Text(common=header_font, x=5, y=5,
     text="Wormhole: multiple, rotated, 6-sided polygons")
poly6 = Common(x=2, y=5, fill=None, sides=6, stroke_width=1)
Polygon(common=poly6, radius=1.50)
Polygon(common=poly6, radius=1.35, rotation=15)
Polygon(common=poly6, radius=1.20, rotation=30)
Polygon(common=poly6, radius=1.05, rotation=45)
Polygon(common=poly6, radius=1.05, rotation=60)
Polygon(common=poly6, radius=0.90, rotation=15)
Polygon(common=poly6, radius=0.75, rotation=30)
Polygon(common=poly6, radius=0.60, rotation=45)
Polygon(x=2, y=5, fill="black", radius=0.60, rotation=60)


Text(common=header_font, x=5, y=9,
     text="Mars Base: rectangle borders + circles with offset radii")
Circle(
   cx=1, cy=9, radius=0.8,
   fill="lightcoral", stroke="firebrick", stroke_width=6)
Circle(
   cx=3.5, cy=9, radius=0.8,
   fill="lightcoral", stroke="firebrick", stroke_width=6)
Rectangle(
    x=1.55, y=8.5, height=1, width=1.4, fill="lightcoral", stroke=None,
    borders=("n s", 6, "firebrick"))
Circle(cx=1, cy=9, radius=0.35, fill=None,
       stroke="firebrick", stroke_width=1,
       radii=[33, 90, 150, 210, 270, 327], radii_offset=0.7,
       radii_stroke_width=1, radii_stroke="firebrick")
Circle(cx=3.5, cy=9, radius=0.35, fill=None,
       stroke="firebrick", stroke_width=1,
       radii=[30, 90, 147, 213, 270, 330], radii_offset=0.7,
       radii_stroke_width=1, radii_stroke="firebrick")


Text(common=header_font, x=5, y=12.5,
     text="German Cross: rectangle with 'o' hatches and 'step' notch")
Rectangle(
    height=2.8, width=2.8, x=0.5, y=11,
    fill="white", stroke="black", stroke_width=2,
    hatches_stroke_width=22, hatches_stroke="black",
    hatches='o', hatches_count=1,
    notch=0.7, notch_style='step',
    centre_shape=rectangle(
        height=2.8, width=2.8,
        fill=None, stroke="white", stroke_width=3)
)


Text(common=header_font, x=5, y=16,
     text="Atom: ellipses with rotation + centre circle")
atom = Common(cx=2, cy=16, width=3, height=1, stroke_width=1, stroke="red", fill=None)
for degrees in [30,150,270]:
    Ellipse(common=atom, rotation=degrees)
Circle(cx=2, cy=16, radius=0.2, fill_stroke="red")


Text(common=header_font, x=5, y=19,
     text="Gear: nested circles; one with 8 offset radii")
Circle(cx=2, cy=19, radius=0.5,
       fill=None, stroke="dimgray", stroke_width=8,
       radii=[0,45,90,135,180,225,270,315],
       radii_offset=0.6, radii_length=0.2,
       radii_stroke="dimgray", radii_stroke_width=8)
Circle(cx=2, cy=19, radius=0.15, fill_stroke="dimgray")


Text(common=header_font, x=5, y=22,
     text="XOK Fish: circles with thick, offset, radii and shapes")
Circle(
    cx=2, cy=22, radius=1,
    fill="#63B1BB", stroke="#63B1BB",
    radii=[135,225],
    radii_offset=0.5, radii_length=1,
    radii_stroke="white", radii_stroke_width=15,
    centre_shape=circle(
        radius=0.75, fill="#63B1BB", stroke="#63B1BB"),
    radii_shapes=[(45, dot(stroke="white", dot_width=5), 0.75)],
    order_last=["radii_shapes"]
)


Text(common=header_font, x=5, y=25,
     text="Sonar screen: nested; offset radii; and slices")
Circle(cx=2, cy=25, radius=1.25,
       fill="#105729", stroke="#27B633",
       nested=6,
       slices=["#077D25"], slices_angles=[30],
       slices_transparency=20,
       # hatches='o', hatches_stroke="#035320",
       radii=steps(0, 360, 5),
       radii_offset=1.1, radii_length=0.125,
       radii_stroke="#01F91E", radii_stroke_width=1.25)

PageBreak()

# ---- PAGE 3 ===>

Text(common=header,
     text="Miscellaneous Things #3")

Text(common=header_font, x=8, y=3,
     text="Camera Frame:")
Text(common=header_font, x=8, y=4,
     text="- Image")
Text(common=header_font, x=8, y=4.75,
     text="- Rectangle: corners; centred shape; perbii")
Text(common=header_font, x=8, y=5.5,
     text="- Dot & Texts")
Image("tmwtgg.jpg",
      width=6.4, height=3.6,
      x=1, y=2)
Rectangle(
    width=6, height=3.2, x=1.2, y=2.2,
    fill=None, stroke=None,
    corners=0.4,
    corners_stroke_width=2,
    centre_shape=rectangle(
        width=2, height=2,
        fill=None, stroke=None,
        corners=0.3,
        corners_stroke="silver",
        corners_stroke_width=1.5),
    perbii="*",
    perbii_stroke_width=2,
    perbii_length=0.4,
    perbii_offset_y=1.8,
    perbii_offset_x=2.8,
    cross=0.5,
    cross_stroke="white",
    cross_stroke_width=1.5)
Dot(fill_stroke="red", dot_width=9, x=1.3, y=2.3)
Text(text="REC",
     x=2.25, y=2.55, stroke="red")
Text(text="00:00:00",
     x=6.5, y=5.3, stroke="white", font_size=10)

Text(common=header_font, x=8, y=7.5,
     text="Tanzanian Flag")
Text(common=header_font, x=8, y=8.5,
     text=" - Rectangle: slices and black diagonal stripe")
Text(common=header_font, x=8, y=9.5,
     text=" - Rectangle: yellow diagonal stripe")
Rectangle(
    width=5.76, height=3.76, x=1.2, y=7,
    fill="white", stroke=None,
    slices=["#18B367", "#00A5DE"],
    stripes=1, stripes_directions="ne",
    stripes_fill="#FCD20E", stripes_breadth=1.52)
Rectangle(
    width=5.76, height=3.76, x=1.2, y=7,
    stroke="white", fill=None,
    stripes=1, stripes_directions="ne",
    stripes_fill="black", stripes_breadth=1.04)

Text(common=header_font, x=8, y=13,
     text="Jewel: Polygon with radii & nested polygon")
Polygon(
    cx=4, cy=13, sides=8, radius=1.5,
    fill_stroke="#388D44",
    radii="*", radii_stroke="azure", radii_stroke_width=3,
    centre_shape=polygon(
        sides=8, radius=1,
        fill="#45A94A", stroke="azure", stroke_width=3
    )
)

Text(common=header_font, x=8, y=17,
     text="Olde Parchment: Polyshape: snail ")
Polyshape(
    x=1, y=18,
    snail="1 a-45 0.2 a45 0.4 a-45 0.4 a45 0.2 e 1 a45 0.3 a-45 0.3 e 1.2 "
    "a-45 0.2 a45 0.2 a-45 0.2 a45 0.5 a-45 0.3 e 0.8 a45 0.1 a-45 0.1 e 1.25 "
    "n 3 w 1.7 a225 0.6 a135 0.4 a225 0.2 a135 0.2 a225 0.1 a125 0.25 w 1.2 "
    "a225 0.2 a135 0.2 w 1.5 a225 0.23 a135 0.25 w 1.45 **",
    stroke="sienna", stroke_width=2, fill="khaki",
    scaling=0.8
)

Text(common=header_font, x=8, y=21,
     text="D10: Polygon with radii & perbii shapes")
d10 = Common(font_name="Times-Bold", font_size=20, stroke="red", rotation=180)
ccom = Common(radius=0.15, fill="gold", label_size=6)
Polygon(
    cx=4, cy=21, sides=5, radius=1.75,
    fill="mistyrose",
    stroke="black",
    perbii_shapes=[
        (1, text(text="1", common=d10), 0.66),
        (2, text(text="9", common=d10), 0.66),
        (3, text(text="5", common=d10), 0.66),
        (4, text(text="3", common=d10), 0.66),
        (5, text(text="7", common=d10), 0.66),
    ],
    perbii_shapes_rotated=True,
    radii="*",
    radii_stroke="silver", radii_stroke_width=1
)

Text(common=header_font, x=8, y=26,
     text="CH4: Filled grid with\n- Circle shapes and Line connectors")
Grid(
  x=1, y=24,
  rows=9, cols=9,
  side=0.5, stroke_width=0.5,
  fill="#001027",
  stroke="#445368",
  omit_outer=True)
cH = Common(radius=0.3, fill="#8142f8", stroke="white", stroke_width=2, label_size=10, label="H")
c1 = Circle(cx=3.25, cy=24.5, common=cH)
c2 = Circle(cx=3.25, cy=28, common=cH)
c3 = Circle(cx=1.5, cy=26.25, common=cH, rotation=90)
c4 = Circle(cx=5, cy=26.25, common=cH, rotation=90)
Line(stroke="white", stroke_width=3, dotted=True, links=[c1, c2])
Line(stroke="white", stroke_width=3, dotted=True, links=[c3, c4])
cC = Circle(cx=3.25, cy=26.25, radius=0.6, fill="#ff004e", stroke="white", stroke_width=3, label_size=18, label="C")

PageBreak()

# ---- PAGE 4 ===>

Text(common=header, text="Miscellaneous Things #4")

Text(common=header_font, x=8, y=3,
     text="Orbit: Filled Grid with Circle\n- Dots & Line use named points")
Grid(
  x=1, y=2,
  rows=9, cols=9,
  side=0.5, stroke_width=0.5,
  fill="#001027",
  stroke="#445368",
  omit_outer=True)
ci = Circle(cx=3.25, cy=4.25, radius=1.5, stroke="white", stroke_width=1, fill=None)
loc = ci.poc(45)
Dot(cxy=loc, fill_stroke="aqua", dot_width=8)
Dot(cxy=ci.geo.c, fill_stroke="tomato", dot_width=16)
Line(xy=ci.geo.c, xy1=loc, stroke="white", dotted=True)

Save()
